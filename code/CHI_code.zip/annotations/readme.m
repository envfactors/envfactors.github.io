%Contains deviation points for 3 routes (R1, R2, R3) and for different
%floors (F-1 = basement, F3 = third floor, F1 = first floor), as well as
%optimal path points. 