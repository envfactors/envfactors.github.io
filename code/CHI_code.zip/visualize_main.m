%% Visualization
datafile = 'datasheet/trajectoryData.csv';
addpath('functions')
% LOAD TRAJECTORY DATA
%This function reads in the trajectory (2D positions) and instructions data (for each time step). 
[trajarray,instructions] = readTrajectoryCSV(datafile);

Isize = [1968 1968]; %in pixels
scale = 9.842; %ratio
origin = [645 1150];  %elevator
x = ([1-origin(1) 1968-origin(1)]-1)./scale;
y = ([1-origin(2) 1968-origin(2)]-1)./scale;
%% Visualize a floor plan in real-world/trajectory coordinates
Ifp = imread('floorplans/coredob1_tps.png');
image(x,y,Ifp(end:-1:1,:,:));
set(gca,'YDir','normal')

%% Visualize floor plan features
close all
load('floorplans/floormap_features.mat')
%%
bremoveS =1;
bwriteout = 0; %save as png
%floor
currFloorReal = -1;
for ift= 1 %1:3 select feature type
    switch currFloorReal
        case -1; Ifp = imread('floorplans/coredob1_tps.png');
        case 3;  Ifp = imread('floorplans/coredo3fs.png');
        case 1;  Ifp = imread('floorplans/coredo1fs.png');
        otherwise; disp('warning'); pause;
    end
    figure(ift)
    floormap = [1 2 3 4];
    flooridx = [-1 1 2 3];
    currfl = floormap(currFloorReal == flooridx);
    
    Iw = getWall(Ifp);
    [ Is ] = getSurround( Iw );
    
    currft = [];
    switch ift
        case 1; currft = ft_floors(currfl).ft1;
        case 2; currft = ft_floors(currfl).ft2;
        case 3; currft = ft_floors(currfl).ft3;
        case 4; currft = ft_floors(currfl).ft4; currft = currft(:,:,1);
        case 5; currft = ft_floors(currfl).ft5; currft = currft(:,:,1);
        case 6; currft = ft_floors(currfl).ft4; currft = currft(:,:,2);
        case 7; currft = ft_floors(currfl).ft5; currft = currft(:,:,2);
        case 8; currft = ft_floors(currfl).ft4; currft = currft(:,:,3);
        case 9; currft = ft_floors(currfl).ft5; currft = currft(:,:,3);
        case 10; currft = ft_floors(currfl).ft4; currft = currft(:,:,4);
        case 11; currft = ft_floors(currfl).ft5; currft = currft(:,:,4);
    end
    %[ currft ] = removeSurroundBG( flipud(currft),Is,[128]/255 );
    if(bremoveS)
        [ currft ] = removeSurroundBG( (currft),flipud(Is),NaN );
    end
    %currft = flipud(currft);
    
    %image(x,y,(255*uint8(currft))); colormap gray
    
    %if(min(min(currft))<0); disp('problem'); pause; end
    currft = currft-min(min(min(currft)));
    currft = currft./max(max(currft));%
    
    %Eshed removed 12/16/17 - why?
    %currft = 64*currft;
    %currft = 64*currft;
    %image(x,y,currft);
    x = ([1-origin(1) 1968-origin(1)]-1)./scale;
    y = ([1-origin(2) 1968-origin(2)]-1)./scale;
    
    imagesc(x,y,currft);
    set(gca,'YDir','normal')
    hold on
    % D = bwdist(~Iw);
    % figure(1)
    % imagesc((D))
    % colormap hot
    
    %colorbar
    %
    
    if(currFloorReal==-1)
        %xlim([-5 60]);
        xlim([-15 70]); %Convert to image...
        ylim([-80 5]);
    elseif(currFloorReal==1)
        xlim([-5 30]);
        ylim([-20 15]);
    elseif(currFloorReal==3)
        xlim([-15 20]);
        ylim([-20 15]);
    end
    %
    axis off
    ax = gca;
    outerpos = ax.OuterPosition;
    ti = ax.TightInset;
    left = outerpos(1) + ti(1);
    bottom = outerpos(2) + ti(2);
    ax_width = outerpos(3) - ti(1) - ti(3);
    ax_height = outerpos(4) - ti(2) - ti(4);
    ax.Position = [left bottom ax_width ax_height-0.02];
    
    fig = gcf;
    fig.PaperPositionMode = 'auto';
    fig_pos = fig.PaperPosition;
    fig.PaperSize = [fig_pos(3) fig_pos(4)];
    
    if(bwriteout)
        print(['Features_ft' num2str(ift) '.png'],'-dpng');
    end
end

%% visualize trajectories

bwriteout = 0;
lw2 = 2; %plot lines
N = 70; %sampling points for planned path

%Need to download these if don't have. 
%cols = brewermap(9,'spectral');
cols = hsv(9);
%cols = cbrewer('qual','Set1',9);
%cols2 = cbrewer('qual','Set3',9);
%cols(end,:) = cols2(1,:);
%cols(6,:) = [0.8 0.8 0];  %[1 0.9 0.1]%[1 1 0]; %[204 204 0]/255;


bremovess = 1;
bPlotOP = 1;
alpval = .8 %.8; %.4; %for s/end circles
opalpha = .4; %FOR OP

bplotGTtraj = 0; %ground truth or estimated

for plist = 1 %:9; %Choose participant
    close all
    for currFloorReal=-1 %[-1 1 3]
        for iR = 1  %Route number
            %Load
            switch currFloorReal
                case -1; Ifp = imread('floorplans/coredob1_tps.png');
                case 3;  Ifp = imread('floorplans/coredo3fs.png');
                case 1;  Ifp = imread('floorplans/coredo1fs.png');
                otherwise; disp('warning'); pause;
            end
            scale = 9.842; %0.1;
            origin = [645 1150];  %should first map to zero zero... how?
            
            x = ([1-origin(1) 1968-origin(1)]-1)./scale;
            y = ([1-origin(2) 1968-origin(2)]-1)./scale;
            
            %remove surround.
            %  Iw = getWall(Ifp);
            %  IfpNS = Iw; %only if color need below
            %[ Is ] = getSurround( Iw );
            %[ IfpNS ] = removeSurroundBG( Ifp,Is,[128 128 128] );
            %%
            % close all
            % Iw = uint8(255*Iw);
            close all
            %Iw = uint8(255*Iw);
            %image(x,y,flipud(Ifp)); %colormap gray
            
            %Find large black connected component
            Ifpbw = Ifp;
            Ifpbw(Ifpbw>0) = 255;
            CC = bwconncomp(~Ifpbw);
            Ifp(CC.PixelIdxList{1}) = 255;
            
            %%
            figure(1);
            hAx(1) = axes();
            image(x,y,Ifp(end:-1:1,:,:));
        
            colormap gray
            set(gca,'YDir','normal')
            hold on
            
            
            [ allpts ] = getPlannedPath( currFloorReal,Isize,origin,scale,N );
            
            %plot(allpts(:,1),allpts(:,2),'g*','color',[0.7 0.7 .7],'MarkerSize',3);
            lw = 10;
            Npts = size(allpts,1);
            z = 0*ones(Npts,1);
            % col = [0.7 0.7 0.7];
            col = [0.2 0.2 0.2];
            
            if(bPlotOP)
                hop =  surface([allpts(:,1)';allpts(:,1)'],[allpts(:,2)';allpts(:,2)'],[z';z'],...
                    'facecol','none',...
                    'edgecol',col,...
                    'linew',lw,...
                    'EdgeAlpha',opalpha); hold on
                
                %
                
                
                
                %             %MARK START AND END
                %             if(currFloorReal==-1)
                %                 if(iR==1)
                %                     %plot(allpts(1,1),allpts(1,2),'ro','color',cols(nP,:),'markersize',solw,'linewidth',1,'markerfacecolor','r','markeredgecolor','r')
                %                     %plot(allpts(end,1),allpts(end,2),'bo','color',cols(nP,:),'markersize',solw,'linewidth',1,'markerfacecolor','b','markeredgecolor','b')
                %                     %%
                %
                %                     s = scatter(allpts(1,1),allpts(1,2),[],myred,'filled','SizeData',200);
                %                     s2 = scatter(allpts(end,1),allpts(end,2),[],mygreen,'filled','SizeData',200);
                %
                %                     alpha(s,alpval); alpha(s2,alpval)
                %                     %   t = linspace(0, 2*pi);
                %                     %   r = 1;
                %                     %   x = allpts(1,1) + r*cos(t);
                %                     %   y = allpts(1,2) + r*sin(t);
                %                     %   patch(x, y, 'r')
                %
                %                 elseif(iR==3)
                %                     % plot(allpts(end,1),allpts(end,2),'ro','color',cols(nP,:),'markersize',solw,'linewidth',1,'markerfacecolor','r','markeredgecolor','r')
                %                     % plot(allpts(1,1),allpts(1,2),'bo','color',cols(nP,:),'markersize',solw,'linewidth',1,'markerfacecolor','b','markeredgecolor','b')
                %
                %                     s = scatter(allpts(end,1),allpts(end,2),[],myred,'filled','SizeData',200);
                %                     s2 = scatter(allpts(1,1),allpts(1,2),[],mygreen,'filled','SizeData',200);
                %
                %                     alpha(s,alpval); alpha(s2,alpval)
                %
                %                 end
                %             elseif(currFloorReal==1)
                %                 if(iR==2)
                %                     % plot(allpts(1,1),allpts(1,2),'ro','color',cols(nP,:),'markersize',solw,'linewidth',1,'markerfacecolor','r','markeredgecolor','r')
                %                     % plot(allpts(end,1),allpts(end,2),'bo','color',cols(nP,:),'markersize',solw,'linewidth',1,'markerfacecolor','b','markeredgecolor','b')
                %
                %                     s = scatter(allpts(1,1),allpts(1,2),[],myred,'filled','SizeData',200);
                %                     s2 = scatter(allpts(end,1),allpts(end,2),[],mygreen,'filled','SizeData',200);
                %
                %                     alpha(s,alpval); alpha(s2,alpval)
                %
                %                 elseif(iR==3)
                %                     %    plot(allpts(end,1),allpts(end,2),'ro','color',cols(nP,:),'markersize',solw,'linewidth',1,'markerfacecolor','r','markeredgecolor','r')
                %                     %    plot(allpts(1,1),allpts(1,2),'bo','color',cols(nP,:),'markersize',solw,'linewidth',1,'markerfacecolor','b','markeredgecolor','b')
                %
                %                     s = scatter(allpts(end,1),allpts(end,2),[],myred,'filled','SizeData',200);
                %                     s2 = scatter(allpts(1,1),allpts(1,2),[],mygreen,'filled','SizeData',200);
                %
                %                     alpha(s,alpval); alpha(s2,alpval)
                %
                %
                %                 end
                %             elseif(currFloorReal==3)
                %                 if(iR==2)
                %                     % plot(allpts(1,1),allpts(1,2),'ro','color',cols(nP,:),'markersize',solw,'linewidth',1,'markerfacecolor','r','markeredgecolor','r')
                %                     % plot(allpts(end,1),allpts(end,2),'bo','color',cols(nP,:),'markersize',solw,'linewidth',1,'markerfacecolor','b','markeredgecolor','b')
                %
                %                     s = scatter(allpts(1,1),allpts(1,2),[],myred,'filled','SizeData',200);
                %                     s2 = scatter(allpts(end,1),allpts(end,2),[],mygreen,'filled','SizeData',200);
                %
                %                     alpha(s,alpval); alpha(s2,alpval)
                %
                %                 elseif(iR==3)
                %                     %  plot(allpts(end,1),allpts(end,2),'ro','color',cols(nP,:),'markersize',solw,'linewidth',1,'markerfacecolor','r','markeredgecolor','r')
                %                     %  plot(allpts(1,1),allpts(1,2),'bo','color',cols(nP,:),'markersize',solw,'linewidth',1,'markerfacecolor','b','markeredgecolor','b')
                %
                %                     s = scatter(allpts(end,1),allpts(end,2),[],myred,'filled','SizeData',200);
                %                     s2 = scatter(allpts(1,1),allpts(1,2),[],mygreen,'filled','SizeData',200);
                %
                %                     alpha(s,alpval); alpha(s2,alpval)
                %
                %                 end
                %             end
            end
            
            npplots = [];
            for nP=plist
                
                % currdata = allarrayinterp{iR,nP};
                currdata2 = trajarray{iR,nP};
               
                hold on
                %2700
                %  plot(currdata(600:end,1),currdata(600:end,2),'r','color',cols(nP,:),'linewidth',0.05);
                %  currdata=currdata(currdata(:,6)==currFloorReal,:);
                currdata2=currdata2(currdata2(:,6)==currFloorReal,:);
                %  plot(currdata(1:end,1),currdata(1:end,2),'r--','color',cols(nP,:),'linewidth',lw2);
                
                %  if(bplotGTtraj)
                npplots(1) =  plot(currdata2(1:end,1),currdata2(1:end,2),'r','color',cols(nP,:),'linewidth',lw2); %,'parent',hAx(2));
                %  else
                npplots(2) =  plot(currdata2(1:end,3),currdata2(1:end,4),'r--','color',cols(nP,:),'linewidth',lw2); %,'parent',hAx(2));
                %  end
            end
            
            hold on
            scsz = 20; alp= 1;
            %for iR = 1
            
            %end
            %
            if(currFloorReal==-1)
                %xlim([-5 60]);
                %%xlim([-15 70]);
                %%ylim([-80 5]);
                xlim([20 58]);
                ylim([-50 -12]);
                
            elseif(currFloorReal==1)
                xlim([-5 30]);
                ylim([-20 15]);
            elseif(currFloorReal==3)
                xlim([-15 20]);
                ylim([-20 15]);
            end
            
            
            
            
            
            %
            %%
            axis off
            ax = gca;
            outerpos = ax.OuterPosition;
            ti = ax.TightInset;
            left = outerpos(1) + ti(1);
            bottom = outerpos(2) + ti(2);
            ax_width = outerpos(3) - ti(1) - ti(3);
            ax_height = outerpos(4) - ti(2) - ti(4);
            ax.Position = [left bottom ax_width ax_height];
            
            fig = gcf;
            fig.PaperPositionMode = 'auto';
            fig_pos = fig.PaperPosition;
            fig.PaperSize = [fig_pos(3) fig_pos(4)];
            
            
            
            %export_fig(['images/Data/iR' num2str(iR) 'Floor' num2str(currFloorReal) '.pdf'],'-transparent');
            %print(['images/DvPts/iR' num2str(iR) 'iP' num2str(i_pt) '.png'],'-dpng','-r600');
            % %,'-r300');
            
            %Next make it nice.
            lists = [];
            for ii=1
                lists{ii} = ['P' num2str(plist) ' - Annotated'];
                lists{ii+1} = ['P' num2str(plist) ' - Estimated'];
            end
            
            
            
            %htemp = plot([0 0],'color','w','parent',hAx(2));
            %  [l2,l2a,l2b,l2c] = legend(npplots,lists) ;
            
            %
            %gl = legend( npplots,lists,'box','off','FontSize',18); %{'Planned Path','Start','Elevator','P1','P2'});
            
            if(iR==3)
                [gl,gic,gpl,gtxt] = legend([hop  npplots],[{'Planned Path'} lists],'box','off','FontSize',15);
                
                %[gl,gic,gpl,gtxt] = legend([hop s s2],[{'Planned Path','Elevator','End'} lists],'box','off'); %,'FontSize',18
            elseif(iR==1)
                [gl,gic,gpl,gtxt] = legend([hop npplots],[{'Planned Path'} lists],'box','off','FontSize',15);
                
                %[gl,gic,gpl,gtxt] = legend([hop s s2],[{'Planned Path','Start','Elevator'} lists],'box','off'); %,'FontSize',18
            end
            
            
            %Next finish the other legend components....
            %Then finalize for reoute 1. make a seperate script for other floors once
            %its nice. Then upload to website.
            
            %gpl are actual patches in image%
            
            %Careful! Plann path has a patch, can modify next.
            for i=1:length(gic)
                if(strcmp(gic(i).Type,'hggroup'))
                    % gic(i).Children.FaceAlpha = alpval;
                    gic(i).Children.MarkerSize = 12;
                elseif(strcmp(gic(i).Type,'patch'))
                    gic(i).Faces = [2 3]; %[3 3 4 3]
                    gic(i).Vertices(:,2)=gic(i).Vertices(:,2)/1.1; %1.01;  %YES!!!
                end
            end
            
            %     hAx(2) = copyobj(hAx(1),gcf);
            %     delete(get(hAx(2),'Children'));
            
            
            %htemp = plot([0 0],'color','w','parent',hAx(2));
            % set(hAx(2),'Color','none','Xtick',[],'YaxisLocation','right','box','off');
            %[l2,l2a,l2b,l2c] = legend(npplots,lists) ;
            %l2.Color = [1 1 1];
            % l2.EdgeColor = [1 1 1];
            %Almost there.... then done and generate.
            % l2.Box = 'off';
            %  l2.Position = [0.869404761257626         0.634920626746284         0.118214286361422 0.361904770079113];
            %    gl.Position = [ 0.643690473091034         0.857301584576804          0.22107143167087 0.12619047891526];
            %      gl.Position = [0.649404756216776 0.694920627654545 0.329642862830843 0.319047626313709];
            if(bwriteout)
                print(['NewFigures\fpersubj\newiP' num2str(plist) 'iR' num2str(iR) 'Floor' num2str(currFloorReal) 'GT' num2str(bplotGTtraj) '.pdf'],'-dpdf'); %,'-r600');
                print(['NewFigures\fpersubj\newiP' num2str(plist) 'iR' num2str(iR) 'Floor' num2str(currFloorReal) 'GT' num2str(bplotGTtraj) '.png'],'-dpng','-r600'); %,'-r600');
                
            end
        end
    end
    
end
