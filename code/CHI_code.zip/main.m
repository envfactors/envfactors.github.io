close all

%SET CSV file location 
datafile = 'datasheet/trajectoryData.csv';

addpath('functions')

%% LOAD TRAJECTORY DATA
%This function reads in the trajectory (2D positions) and instructions data (for each time step). 
[trajarray,instructions] = readTrajectoryCSV(datafile);

%% Extract features from floor plan.
bLoadPreComputed = 0;
if(bLoadPreComputed)
    load('floorplans/floormap_features.mat');
else
    %Takes about 5 minutes
    ft_floors = [];
    floors = [-1 1 2 3]; %Basement -1, first floor 1, second 2, third 3.
    parfor i_f = 1:length(floors)
        disp(num2str(i_f)); tic;
        %Load image
        currFloorReal = floors(i_f);
        switch currFloorReal
            case -1; Ifp = imread('floorplans/coredob1_tps.png');
            case 3;  Ifp = imread('floorplans/coredo3fs.png');
            case 1;  Ifp = imread('floorplans/coredo1fs.png');
            case 2;  Ifp = imread('floorplans/coredo2fs.png');
            otherwise; disp('warning, unrecognized floor'); pause;
        end
        
        Iw = getWall(Ifp);
        
        wI = ~Iw;
        [ Is ] = getSurround( Iw );
        [ IwNP ] = getWNP( Iw );
        
        Dwnp = bwdist(IwNP);
        ft1 = flipud(Dwnp );
        %ft1 = ft1./max(max(ft1));
        ft_floors(i_f).ft1 = ft1;
        
        [ It ] = getTact(Ifp);
        Dt = bwdist(It(:,:,1));
        [ Dtac ] = removeSurroundBG( Dt,Is );
        %Dtac = Dtac./max(max(max(Dtac))); % colorbar;
        ft2 = flipud(Dtac);
        ft_floors(i_f).ft2 = ft2;
        
        d1 = abs(wI-IwNP);
        Dp = bwdist(d1);
        [ Dpole ] = removeSurroundBG( Dp,Is );
        ft3 = flipud(Dpole);
        ft_floors(i_f).ft3 = ft3;
        
        [ distmap,gradmap ] = getSurroundWO( IwNP );
        ft4 = flipud(distmap);
        %ft4 = ft4./max(max(max(max(ft4))));
        ft_floors(i_f).ft4 = ft4;
        
        %Orientation normalization.
        ft5 = flipud(gradmap);
        %ft5 = (ft5-min(min(min(min(ft5)))))./max(max(max(max(ft5))));
        ft5(:,:,5) = [];
        ft_floors(i_f).ft5 = ft5;
        disp(num2str(i_f)); toc;
    end
    
    %save('floormap_features.mat','ft_floors','floors');
end
%%
%May be inf if empty (i.e. 2nd floor has no tactile). 
Isize = [1968 1968]; %Sets to a large value. For now, its the floorplan image size 
scale = 9.842; %0.1;
origin = [645 1150]; 
x = ([1-origin(1) 1968-origin(1)]-1)./scale;
y = ([1-origin(2) 1968-origin(2)]-1)./scale;



[ft_floors] = removeInf(ft_floors,Isize);
%%
[ftS,ftE,obstmap] = getLandmarks(Isize); %ftS is stair distance features, ftE is elevator. 

%% Planned path features
N = 70; %Sampling rate for planned path
[ allpts ] = getPlannedPath( currFloorReal,Isize,origin,scale,N );

curves = getCurvature(allpts(:,1),allpts(:,2));
A = [1 -1]'; B = [1 0 0 0 -1]'; C = [ 1 0 0 0 0 0 0 -1]'; %Capture different statistics of the planned path within the surrounding space
slopes = convolve2(allpts,A,'replicate');
slopes2 = convolve2(allpts,B,'replicate');
slopes3 = convolve2(allpts,C,'replicate');

