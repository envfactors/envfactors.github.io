function curvature = getCurvature(x,y)
dx  = gradient(x);
ddx = gradient(dx);
dy  = gradient(y);
ddy = gradient(dy);
num   = dx .* ddy - ddx .* dy;
denom = dx .* dx + dy .* dy;
denom = sqrt(denom);
denom = denom .* denom .* denom;

%added
denom(denom<0.00001) = 0.00001;

curvature = num ./ denom;
curvature(denom < 0) = NaN;

curvature(curvature<0.0001) = 0;

if(sum(isnan(curvature))>0)
    disp('warning'); pause;
end
%%
end