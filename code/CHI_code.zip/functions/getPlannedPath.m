function [ allptsnomove,tmirror ] = getPlannedPath( currFloorReal,Isize,origin,scale,N,varargin )
%LOG
%added unique path. must be unique points.

allpts = [];

t= dlmread(['annotations/OP_F' num2str(currFloorReal) '.txt']);
tmirror = [t(:,1) Isize(1)-t(:,2)+1]; %size(Ifp,1)
tmirror = (tmirror-repmat(origin,[size(tmirror,1) 1])-1)./scale;

for i=1:size(t,1)-1
    maxT = (tmirror(i+1,1));
    minT = (tmirror(i,1));
    
    %%
    %y = linspace(tmirror(i:i+1,1), tmirror(i:i+1,2), N);
    %%
    if(maxT==minT)
        %need to interpolate by y...
        maxT = (tmirror(i+1,2));
        minT = (tmirror(i,2));
        yq = linspace(minT,maxT,N);
        xq = interp1(tmirror(i:i+1,2),tmirror(i:i+1,1),yq);
    else
        xq = linspace(minT,maxT,N);
        yq = interp1(tmirror(i:i+1,1),tmirror(i:i+1,2),xq);
    end
    %allpts{i} = [xq' yq'];
    allpts = [allpts;xq' yq'];
    
end


allptsnomove = allpts(1,:);
for i = 2:size(allpts,1)
    if(sum(abs(allpts(i,:)-allpts(i-1,:))) < 0.00000001)
        %disp('he');
    else
        allptsnomove = [allptsnomove;allpts(i,:)];
    end
end

end




