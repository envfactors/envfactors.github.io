function [allarray,instructions] = readTrajectoryCSV(datafile)

[num,txt,raw] = xlsread(datafile);

% there are 3 routes, 9 participants. 
allarray = cell(3,9); 
instructions = cell(3,9);

%interpolating floor, just make sure OK.
for i=2:size(txt,1) %starts on row 2
    currRoute = txt{i,3};
    currPerson = txt{i,2};
    iR = str2num(currRoute(2:end));
    nP = str2num(currPerson(2:end));
    pos = num(i-1,[11 12 9 10 5 19]);  %num starts one index less. 19 is real floor.
    
    allarray{iR,nP} = [allarray{iR,nP};pos];
    
    currcommand = [];
    if(~isempty(txt(i,16)))  %Reading in current time, i, from table, which is actual i-1
        currcommand = txt{i,16};
        
        if(isempty(instructions{iR,nP}))
            instructions{iR,nP}.id = [];
            instructions{iR,nP}.command = [];
        end
        
        instructions{iR,nP}.id{end+1} = size(allarray{iR,nP},1); % i-1; %since first row is header in text
        instructions{iR,nP}.command{end+1} = currcommand;
    end
end

%%

for i=1:size(allarray,1)
    for j=1:size(allarray,2)
        olddata = allarray{i,j};
        currdata = naninterp(allarray{i,j});
        allarray{i,j} = currdata;
    end
end

end

