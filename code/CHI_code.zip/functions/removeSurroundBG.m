function [ Iwk ] = removeSurroundBG( Iwk,Is,varargin )
%REMOVESURROUNDBG process the wall map and removes areas outside of the
%floor
valtochange = 0;
if nargin >2
    valtochange = varargin{1};
end

% for i=1:size(Iwk,1)
%     for j=1:size(Iwk,2)
%         if(Is(i,j,1)==1)
%             Iwk(i,j,:) = valtochange;
%         end
%     end
% end

Iwk(logical(Is)) = valtochange;

end

