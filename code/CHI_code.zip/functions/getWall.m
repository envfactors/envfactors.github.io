function wallI = getWall(Ifp)
%getImage
Ifp = double(Ifp);

thresh = 200;
for i=1:size(Ifp,1)
    for j=1:size(Ifp,2)
        blackcond = Ifp(i,j,1)<thresh && Ifp(i,j,2)<thresh && Ifp(i,j,3)<thresh;
        if(blackcond)
            
        else
            Ifp(i,j,:) = 255;
        end
    end
end
%imagesc(uint8(Ifp))
%%
Ifp(Ifp<255) = 0;
Ifp(Ifp==255)=1;
%imagesc((Ifp))
%%
wallI = Ifp(:,:,1);
%figure(2)
%imshow(wallI)
%%
