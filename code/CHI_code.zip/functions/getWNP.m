function [ IwNP ] = getWNP( Iw )
%Get walls without poles map

wI = ~Iw;

CC = bwconncomp(wI, 4);
S = regionprops(CC, 'BoundingBox','Area','PixelIdxList');
L = labelmatrix(CC);
%imagesc(L)
%hold on;

wallt = 5; %3 pixels. usually.

Iw2 = wI;
for i=1:length(S)
    %rectangle('position',S(i).BoundingBox);
    curra = S(i).Area;
    x1 = S(i).BoundingBox(1);
    y1 = S(i).BoundingBox(2);
    x2 = x1+S(i).BoundingBox(3);
    y2 = y1+S(i).BoundingBox(4);
    
    boxa = S(i).BoundingBox(3)*S(i).BoundingBox(4);
    
    d1 = x2-x1; d2 = y2-y1;
    longc = d1 <wallt || d2<wallt;
    
    if(curra<10000 && abs(boxa-curra)<50 && ~longc) %Area, but also number of pixels about same as area...
        
        Iw2(y1:y2,x1:x2) = 0;
        
        %Show as it deletes
        %  imshow(Iw2)
        %  pause(.1)
    end
end
%imshow(Iw2)
%%
IwNP = Iw2(:,:,1);
end

