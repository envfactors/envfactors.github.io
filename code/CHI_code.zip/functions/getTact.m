function [ Inew ] = getTact( Ifp )
%Get tactile only

Ifp = double(Ifp);
Inew = Ifp;
thresh = 20;
for i=1:size(Ifp,1)
    for j=1:size(Ifp,2)
        blackcond = abs(Ifp(i,j,1)-245)<thresh && abs(Ifp(i,j,2)-170)<thresh && abs(Ifp(i,j,3)-38)<thresh;
        if(blackcond)
            %Comment to leave colored
            Inew(i,j,:) = [1 1 1];
        else
            Inew(i,j,:) = [0 0 0];
        end
    end
end

end

