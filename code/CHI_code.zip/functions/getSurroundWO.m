function [ distmap,gradmap ] = getSurroundWO( IwNP )
%GETSURROUNDWO - surround wall distance and orientation

wc = IwNP;
wc = wc(:,:,1);
[Gmag,Gdir] = imgradient(wc);
distmap = [];
gradmap = [];
for i=1:size(wc,1)
    for j=1:size(wc,1)
        %For each pixel, if 1 set to 0. if 0, have four numbers. slow. 
        
        if(wc(i,j)==1)
            distmap(i,j,1:4) = 0;
            gradmap(i,j,5) = -181;  %-180-180...
        else
            %Find nearest nonzero in each direction
            [nz, nzidx] = find(wc(i,:));
            [offset1, offsetidx1] = min(abs(j - nzidx)); %along the other dimension
            %Its now either right before or right after. 
            
            offsetidx2 = [];
            %If its less than j, than next one is>. else otherway.
            if(offsetidx1<j)
                offsetidx2 =(offsetidx1+1);
                 %to left, right, bottom, up
                d1 = abs(j-nzidx(offsetidx1));
                d2 = abs(j-nzidx(offsetidx2));
                
                o1 = Gdir(i,nzidx(offsetidx1)); %direction in i row, offseted
                o2 = Gdir(i,nzidx(offsetidx2)); 
            else
                offsetidx2 =(offsetidx1-1);
                 %to left, right, bottom, up
                d2 = abs(j-nzidx(offsetidx1));
                d1 = abs(j-nzidx(offsetidx2));
                
                o2 = Gdir(i,nzidx(offsetidx1)); %direction in i row, offseted
                o1 = Gdir(i,nzidx(offsetidx2)); 
            end
                        
           
            
            [nz, nzidx] = find(wc(:,j)'); %Very weird... must be a row vector, otherwise weird. 
            [offset1, offsetidx1] = min(abs(i - nzidx));            
            offsetidx2 = [];
            if(offsetidx1<i)
                offsetidx2 =(offsetidx1+1);
                d3 = abs(i-nzidx(offsetidx1));
                d4 = abs(i-nzidx(offsetidx2));
                
                o3 = Gdir(nzidx(offsetidx1),j); %direction in j col, offseted
                o4 = Gdir(nzidx(offsetidx2),j); 
            else
                offsetidx2 =(offsetidx1-1);
                d4 = abs(i-nzidx(offsetidx1));
                d3 = abs(i-nzidx(offsetidx2));
                
                o4 = Gdir(nzidx(offsetidx1),j); %direction in j col, offseted
                o3= Gdir(nzidx(offsetidx2),j); 
            end
                       
            
            distmap(i,j,1) = d1;
            distmap(i,j,2) = d2;
            distmap(i,j,3) = d3;
            distmap(i,j,4) = d4;
            
            gradmap(i,j,1) = o1;
            gradmap(i,j,2) = o2;
            gradmap(i,j,3) = o3;
            gradmap(i,j,4) = o4;
       end     
   end
end
end

