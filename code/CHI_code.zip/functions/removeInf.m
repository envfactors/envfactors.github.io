function [ft_floors] = removeInf(ft_floors,Isize)
for i= 1:length(ft_floors)
    infidx = isinf(ft_floors(i).ft1);
    ft_floors(i).ft1(infidx) = Isize(1);
    
    infidx = isinf(ft_floors(i).ft2);
    ft_floors(i).ft2(infidx) = Isize(1);
    
    infidx = isinf(ft_floors(i).ft3);
    ft_floors(i).ft3(infidx) = Isize(1);
    
    infidx = isinf(ft_floors(i).ft4);
    ft_floors(i).ft4(infidx) = Isize(1);
    
    infidx = isinf(ft_floors(i).ft5);
    ft_floors(i).ft5(infidx) = Isize(1);
end
end

