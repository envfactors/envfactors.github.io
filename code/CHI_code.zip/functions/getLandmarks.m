function [ftS,ftE,obstmap] = getLandmarks(Isize)
ftStairs = zeros(Isize);

%set stairs
ftStairs(779:853,793:820) = 1;
ftStairs(952:982,763:832) = 1;

ftS = flipud(bwdist(ftStairs));
infidx = isinf(ftS); ftS(infidx) = Isize(1);

ftElevator = zeros(Isize);
ftElevator(823:823,654:654) = 1;
ftElevator(1202:1202,1005:1005) = 1;

ftE = flipud(bwdist(ftElevator));
infidx = isinf(ftE); ftE(infidx) = Isize(1);

%Obstacles for each floor
obstmap = [];
floors = [-1 1 2 3];
obstypes = {'door','obstacles'}; %,'misc'};

for i_f = 1:length(floors)
    iff = floors(i_f);
    for j_f = 1:length(obstypes)
        currobjtype = obstypes{j_f};
        fname = ['features/matrix_nav_' currobjtype '_floor_' num2str(iff) '.mat'];
        
        try
            temp = load(fname);
            temp = temp.arr;
            temp = bwdist(temp);
        catch err
            %temp = zeros(Isize(1),Isize(2)); %so all inf... instead
            temp = Isize(1)*ones(Isize(1),Isize(2));
        end
        
        obstmap{i_f,j_f} = flipud(temp);
    end
end
end

