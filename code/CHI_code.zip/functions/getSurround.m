function [ iBW ] = getSurround( Iw )
%gets the black area around map, to remove when visual.
%Takes in wall image. 
wI = ~Iw;
%Extract pixels in largest connected component...
CC = bwconncomp(wI, 4);
S = regionprops(CC, 'BoundingBox','Area','PixelIdxList');

%Try to remove small CC
wI2 = wI;
for i=2:length(S)
    wI2(S(i).PixelIdxList) = 0;
end

se = strel('square', 30);
closeBW = imclose(~wI2,se);
iBW = ~closeBW;
end

